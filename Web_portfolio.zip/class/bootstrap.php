<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="./bootstrap-5.1.3-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="./bootstrap-5.1.3-dist/css/bootstrap.css">
<link rel="stylesheet" href="./css/mdb.min.css">
<script  src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="./bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="./js/mdb.min.js"></script>
