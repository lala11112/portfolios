<?php
include_once("./class/bootstrap.php");
?>
<?php
  if($userlevel != 9){
?>
<script type="text/javascript">

  alert("관리자가 아닙니다.");
</script>
<?php
}
?>
        <div class="col-sm-auto bg-light sticky-top">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline">관리자 메뉴</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="../admin_user.php" class="nav-link align-middle px-0">
                            <i class="bi bi-person-circle"></i> <span class="ms-1 d-none d-sm-inline">유저 정보</span>
                        </a>
                    </li>
                    <li>
                        <a href="#submenu1" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="bi bi-book"></i> <span class="ms-1 d-none d-sm-inline">목차</span> </a>
                        <ul class="collapse show nav flex-column ms-1" id="submenu1" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="../admin_chapter_make_form.php" class="nav-link px-0"> <span class="d-none d-sm-inline">목차 생성</span></a>
                            </li>
                            <li>
                                <a href="../admin_chapter_update_form.php" class="nav-link px-0"> <span class="d-none d-sm-inline">목차 수정</span></a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="../admin_board_modity_form.php" class="nav-link align-middle px-0">
                           <i class="bi bi-file-earmark-text"></i> <span class="ms-1 d-none d-sm-inline">게시글 수정</span>
                        </a>
                    </li>
                    <li>
                        <a href="../index.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-people"></i> <span class="ms-1 d-none d-sm-inline">메인 페이지</span> </a>
                    </li>
                </ul>
                <hr>
            </div>
        </div>
