<?php
  $con = mysqli_connect("localhost", "pjw", "pjw20040715", "pjwweb");
 ?>
