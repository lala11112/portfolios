<?php
include_once("./header.php");
?>
<?php
include_once("./class/bootstrap.php");
?>
<?php
include_once("./class/db.php");
?>
<div class="container-fluid">
    <div class="row flex-nowrap">
        <?php
          include_once("./class/admin_menu.php");
        ?>
        <div class="col-sm p-3 min-vh-100">
