<?php
include_once("./class/admin_header.php");
?>
<div>콘텐츠 창입니다.</div>
<?php
  include_once("./class/admin_footer.php");
?>
